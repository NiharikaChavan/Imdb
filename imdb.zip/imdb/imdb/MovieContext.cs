﻿

using imdb.EntityConfiguration;
using imdb.Models;
using Microsoft.EntityFrameworkCore;

namespace imdb
{
    public class MovieContext:DbContext
    {
        public MovieContext(DbContextOptions<MovieContext> options):base(options)
        {

        }
        public MovieContext()
        {

        }
        public DbSet<MovieModel> Movies { get; set; }
        public DbSet<ActorModel> Actors { get; set; }
        public DbSet<MovieActorRel> MovieActorRels { get; set; }
        public DbSet<ProducerModel> Producers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new MovieEntityTypeConfiguration());
            modelBuilder.ApplyConfiguration(new ActorEntityTypeConfiguration());
            modelBuilder.ApplyConfiguration(new ProducerEntityTypeConfiguration());
            modelBuilder.ApplyConfiguration(new MovieActorEntityTypeConfiguration());
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
        }
    }
}
