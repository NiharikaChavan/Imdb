﻿using imdb.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace imdb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : ControllerBase
    {
        private readonly MovieContext mMovieContext;
        public MoviesController(MovieContext pMovieContext)
        {
            mMovieContext = pMovieContext;

        }

        [HttpGet]
        public List<MovieModel> GetAllMovies()
        {
            var tMov= mMovieContext.Movies.Include(x => x.MovieActorRels).ThenInclude(x => x.Actor);
           var tMovies =tMov.Include(x => x.Producer).ToList(); 
            
            return tMovies;

            
        }
        [HttpPost]
        public MovieModel CreateMovie(MovieDTOI movie)
        {
            MovieModel pMovie = new MovieModel();
            MovieActorRel ma = new MovieActorRel();

            pMovie.MovieName = movie.MovieName;
            pMovie.MovieId = movie.MovieId;
            pMovie.DateOfRelease = movie.DateOfRelease;
            pMovie.MovieActorRels = new List<MovieActorRel>();
          
            foreach(var i in movie.Actor)
            {
                var tActors = mMovieContext.Actors.Where(x => x.ActorId == i.ActorId).FirstOrDefault();
                ma.MA_ActorId = tActors.ActorId;
            }
          
            var tProducer = mMovieContext.Producers.Where(x => x.ProducerId == movie.Producer.ProducerId).FirstOrDefault();

           
             ma.MA_MovieId = movie.MovieId;
          
            pMovie.Producer = tProducer;
            pMovie.MovieActorRels.Add(ma);
            mMovieContext.Movies.Add(pMovie);
            mMovieContext.MovieActorRels.Add(ma);

            mMovieContext.SaveChanges();
         
            return pMovie;
        }

        [HttpPut]
        public MovieModel UpdateMovie(MovieDTOI movie)
        {
            mMovieContext.Database.BeginTransaction();
            MovieModel pMovie = new MovieModel();
            pMovie.MovieName = movie.MovieName;
            pMovie.MovieId = movie.MovieId;
            pMovie.DateOfRelease = movie.DateOfRelease;
            mMovieContext.SaveChanges();
            foreach (var i in movie.Actor)
            {
                var tActor = mMovieContext.Actors.Where(x => x.ActorId == i.ActorId).FirstOrDefault();
                tActor.ActorName = i.ActorName;
                mMovieContext.SaveChanges();
            }
            var tProducer = mMovieContext.Producers.Where(x => x.ProducerId == movie.Producer.ProducerId).FirstOrDefault();
            tProducer.ProducerName = movie.Producer.ProducerName;
            mMovieContext.SaveChanges();

            pMovie.Producer = tProducer;

            mMovieContext.Database.CommitTransaction();
            return pMovie;

        }
    }
}
