﻿using imdb.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace imdb.EntityConfiguration
{
    public class ActorEntityTypeConfiguration : IEntityTypeConfiguration<ActorModel>
    {
        public void Configure(EntityTypeBuilder<ActorModel> pBuilder)
        {
            pBuilder
                .ToTable("ActorTB".ToLower())
                .HasKey(col => new { col.ActorId });

            pBuilder
                .Property(col => col.ActorName)
                .HasColumnName("name".ToLower());

            pBuilder
          .Property(col => col.ActorId)
          .HasColumnName("ActorId".ToLower())
          .IsRequired();

        }
    }
}
