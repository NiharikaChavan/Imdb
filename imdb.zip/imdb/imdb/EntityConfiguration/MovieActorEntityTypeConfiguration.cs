﻿using imdb.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace imdb.EntityConfiguration
{
    public class MovieActorEntityTypeConfiguration : IEntityTypeConfiguration<MovieActorRel>
    {
        public void Configure(EntityTypeBuilder<MovieActorRel> pBuilder)
        {


            pBuilder
                .ToTable("MovieActorRel".ToLower())
                .HasKey(col => new { col.MA_MovieId, col.MA_ActorId });

            pBuilder
                .HasOne<MovieModel>(col => col.Movie)
                .WithMany(col => col.MovieActorRels)
                .HasForeignKey(col => col.MA_MovieId);

            pBuilder
     .HasOne<ActorModel>(col => col.Actor)
     .WithMany(col => col.MovieActorRels)
     .HasForeignKey(col => col.MA_ActorId);

            pBuilder
                .Property(col => col.MA_MovieId)
                .HasColumnName("MA_MovieId".ToLower())
                .IsRequired();

            pBuilder
          .Property(col => col.MA_ActorId)
          .HasColumnName("MA_ActorId".ToLower())
          .IsRequired();

        }
    }
}
