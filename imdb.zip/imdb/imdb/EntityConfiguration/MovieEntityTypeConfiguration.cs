﻿using imdb.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace imdb.EntityConfiguration
{
    public class MovieEntityTypeConfiguration : IEntityTypeConfiguration<MovieModel>
    {
        public void Configure(EntityTypeBuilder<MovieModel> pBuilder)
        {
            pBuilder
                .HasOne(col => col.Producer)
                .WithMany(col => col.Movies);

            pBuilder
                .ToTable("MovieTB".ToLower())
                .HasKey(col => new { col.MovieId });

            pBuilder
                .Property(col => col.MovieName)
                .HasColumnName("name".ToLower());

            pBuilder
          .Property(col => col.MovieId)
          .HasColumnName("MovieId".ToLower())
          .IsRequired();

            pBuilder
                .Property(col => col.DateOfRelease)
                .HasColumnName("dateofrelease".ToLower());
            pBuilder
            .Property(col => col.ProducerId)
            .HasColumnName("ProducerId".ToLower())
            .IsRequired();
        }
    }
}
