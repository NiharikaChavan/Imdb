﻿using imdb.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace imdb.EntityConfiguration
{
    public class ProducerEntityTypeConfiguration : IEntityTypeConfiguration<ProducerModel>
    {
        public void Configure(EntityTypeBuilder<ProducerModel> pBuilder)
        {
            pBuilder
                .HasMany(col => col.Movies)
                .WithOne(col => col.Producer);
            pBuilder
                .ToTable("ProducerTB".ToLower())
                .HasKey(col => new { col.ProducerId });

            pBuilder
                .Property(col => col.ProducerName)
                .HasColumnName("name".ToLower());

            pBuilder
          .Property(col => col.ProducerId)
          .HasColumnName("producerid".ToLower())
          .IsRequired();

        }

    }

}
