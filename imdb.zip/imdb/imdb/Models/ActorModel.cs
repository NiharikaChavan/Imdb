﻿namespace imdb.Models
{
    public class ActorModel
    {
        public String ActorName { get; set; }
        public Int32 ActorId { get; set; }
        public List<MovieActorRel> MovieActorRels { get; set; }
    }
}
