﻿namespace imdb.Models
{
    public class MovieActorRel
    {
        public Int32 MA_MovieId { get; set; }
        public Int32 MA_ActorId { get; set; }
        public MovieModel? Movie { get; set; }
        public ActorModel ?Actor { get; set; }
    }
}
