﻿namespace imdb.Models
{
    public class MovieModel
    {
        public String MovieName { get; set; }
        public Int32 MovieId { get; set; }

        public DateTime DateOfRelease { get; set; }

       public Int32 ProducerId { get; set; }

        public List<MovieActorRel> ? MovieActorRels { get; set; }
        public ProducerModel Producer { get; set; }

    }
}
