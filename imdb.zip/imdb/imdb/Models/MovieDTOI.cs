﻿namespace imdb.Models
{
    public class MovieDTOI
    {
        public String MovieName { get; set; }
        public Int32 MovieId { get; set; }
        public DateTime DateOfRelease { get; set; }
        public List<Actor> Actor { get; set; }
        public Producer Producer { get; set; }
    }

    public class Actor
    {
        public String ActorName { get; set; }
        public Int32 ActorId { get; set; }
    }

    public class Producer
    {
        public String ProducerName { get; set; }
        public Int32 ProducerId { get; set; }

    }
}
