﻿namespace imdb.Models
{
    public class ProducerModel
    {
        public String ProducerName { get; set; }
        public Int32 ProducerId { get; set; }

        public List<MovieModel> Movies { get; set; }
    }
}
