﻿using imdb.Models;

namespace imdb.ViewModels
{
    public class MovieViewModel
    {
        public String MovieName { get; set; }
        public String MovieId { get; set; }
   
    }
}
